run.def("i18n!dijit/nls/nl/common",
{
	buttonOk: "OK",
	buttonCancel: "Annuleren",
	buttonSave: "Opslaan",
	itemClose: "Sluiten"
});
