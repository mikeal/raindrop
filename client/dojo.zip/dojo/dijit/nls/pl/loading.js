run.def("i18n!dijit/nls/pl/loading",
{
	loadingState: "Ładowanie...",
	errorState: "Niestety, wystąpił błąd"
});
