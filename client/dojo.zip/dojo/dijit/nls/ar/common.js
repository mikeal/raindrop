run.def("i18n!dijit/nls/ar/common",
{
	buttonOk: "حسنا",
	buttonCancel: "الغاء",
	buttonSave: "حفظ",
	itemClose: "اغلاق"
});
