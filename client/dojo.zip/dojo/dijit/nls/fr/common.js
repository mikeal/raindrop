run("i18n!dijit/nls/fr/common",
{
	buttonOk: "OK",
	buttonCancel: "Annuler",
	buttonSave: "Sauvegarder",
	itemClose: "Fermer"
});
