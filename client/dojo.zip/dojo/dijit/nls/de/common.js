run.def("i18n!dijit/nls/de/common",
{
	buttonOk: "OK",
	buttonCancel: "Abbrechen",
	buttonSave: "Speichern",
	itemClose: "Schließen"
});
