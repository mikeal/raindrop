run.def("i18n!dijit/nls/de/loading",
{
	loadingState: "Wird geladen...",
	errorState: "Es ist ein Fehler aufgetreten."
});
