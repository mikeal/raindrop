run.def("i18n!dijit/nls/it/loading",
{
	loadingState: "Caricamento in corso...",
	errorState: "Si è verificato un errore"
});
