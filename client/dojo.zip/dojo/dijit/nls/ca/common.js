run.def("i18n!dijit/nls/ca/common",
{
	buttonOk: "D'acord",
	buttonCancel: "Cancel·la",
	buttonSave: "Desa",
	itemClose: "Tanca"
});
