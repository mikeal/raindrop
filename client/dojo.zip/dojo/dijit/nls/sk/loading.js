run("i18n!dijit/nls/sk/loading",
{
	loadingState: "Zavádzanie...",
	errorState: "Nastala chyba"
});
