run.def("i18n!dijit/nls/loading",
{ "root": {
	loadingState: "Loading...",
	errorState: "Sorry, an error occurred"
},
"ar": true,
"ca": true,
"cs": true,
"da": true,
"de": true,
"el": true,
"es": true,
"fi": true,
"fr": true,
"he": true,
"hu": true,
"it": true,
"ja": true,
"ko": true
});
