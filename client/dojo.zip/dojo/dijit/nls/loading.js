run("i18n!dijit/nls/loading",
{ "root": {
	loadingState: "Loading...",
	errorState: "Sorry, an error occurred"
},
"ar": "i18n!dijit/nls/ar/loading",
"ca": "i18n!dijit/nls/ca/loading",
"cs": "i18n!dijit/nls/cs/loading",
"da": "i18n!dijit/nls/da/loading",
"de": "i18n!dijit/nls/de/loading",
"el": "i18n!dijit/nls/el/loading",
"es": "i18n!dijit/nls/es/loading",
"fi": "i18n!dijit/nls/fi/loading",
"fr": "i18n!dijit/nls/fr/loading",
"he": "i18n!dijit/nls/he/loading",
"hu": "i18n!dijit/nls/hu/loading",
"it": "i18n!dijit/nls/it/loading",
"ja": "i18n!dijit/nls/ja/loading",
"ko": "i18n!dijit/nls/ko/loading"
});
