run.def("i18n!dijit/nls/da/common",
{
	buttonOk: "OK",
	buttonCancel: "Annullér",
	buttonSave: "Gem",
	itemClose: "Luk"
});
