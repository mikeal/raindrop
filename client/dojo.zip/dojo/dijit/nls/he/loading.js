run.def("i18n!dijit/nls/he/loading",
{
	loadingState: "טעינה...‏",
	errorState: "אירעה שגיאה"
});
