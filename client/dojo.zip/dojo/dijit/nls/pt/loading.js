run("i18n!dijit/nls/pt/loading",
{
	loadingState: "Carregando...",
	errorState: "Desculpe, ocorreu um erro"
});
