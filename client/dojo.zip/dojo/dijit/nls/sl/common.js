run.def("i18n!dijit/nls/sl/common",
{
	buttonOk: "V redu",
	buttonCancel: "Prekliči",
	buttonSave: "Shrani",
	itemClose: "Zapri"
});
