run("i18n!dijit/_editor/nls/fr/LinkDialog",
{
	createLinkTitle: "Propriétés du lien",
	insertImageTitle: "Propriétés de l'image",
	url: "URL :",
	text: "Description :",
	set: "Définir"
});
