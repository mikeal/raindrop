run("i18n!dijit/_editor/nls/FontChoice",
{ "root": {
	fontSize: "Size",
	fontName: "Font",
	formatBlock: "Format",

	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",

	p: "Paragraph",
	h1: "Heading",
	h2: "Subheading",
	h3: "Sub-subheading",
	pre: "Pre-formatted",

	1: "xx-small",
	2: "x-small",
	3: "small",
	4: "medium",
	5: "large",
	6: "x-large",
	7: "xx-large"
},
"ar": "i18n!dijit/_editor/nls/ar/FontChoice",
"ca": "i18n!dijit/_editor/nls/ca/FontChoice",
"cs": "i18n!dijit/_editor/nls/cs/FontChoice",
"da": "i18n!dijit/_editor/nls/da/FontChoice",
"de": "i18n!dijit/_editor/nls/de/FontChoice",
"el": "i18n!dijit/_editor/nls/el/FontChoice",
"es": "i18n!dijit/_editor/nls/es/FontChoice",
"fi": "i18n!dijit/_editor/nls/fi/FontChoice"
});
