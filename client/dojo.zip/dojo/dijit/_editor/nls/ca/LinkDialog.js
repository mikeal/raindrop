run.def("i18n!dijit/_editor/nls/ca/LinkDialog",
{
	createLinkTitle: "Propietats de l'enllaç",
	insertImageTitle: "Propietats de la imatge",
	url: "URL:",
	text: "Descripció:",
	set: "Defineix"
});
