window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.ca.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.ca.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "ca", {"set":"Defineix","text":"Descripció:","insertImageTitle":"Propietats de la imatge","url":"URL:","createLinkTitle":"Propietats de l'enllaç"});
}};});