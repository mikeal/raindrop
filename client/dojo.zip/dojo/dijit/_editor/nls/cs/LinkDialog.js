run.def("i18n!dijit/_editor/nls/cs/LinkDialog",
{
	createLinkTitle: "Vlastnosti odkazu",
	insertImageTitle: "Vlastnosti obrázku",
	url: "Adresa URL:",
	text: "Popis:",
	set: "Nastavit"
});
