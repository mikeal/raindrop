window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.cs.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.cs.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "cs", {"set":"Nastavit","text":"Popis:","insertImageTitle":"Vlastnosti obrázku","url":"Adresa URL:","createLinkTitle":"Vlastnosti odkazu"});
}};});