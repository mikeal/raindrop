run.def("i18n!dijit/_editor/nls/it/LinkDialog",
{
	createLinkTitle: "Proprietà collegamento",
	insertImageTitle: "Proprietà immagine",
	url: "URL:",
	text: "Descrizione:",
	set: "Imposta"
});
