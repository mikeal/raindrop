run.def("i18n!dijit/_editor/nls/tr/LinkDialog",
{
	createLinkTitle: "Bağlantı Özellikleri",
	insertImageTitle: "Resim Özellikleri",
	url: "URL:",
	text: "Açıklama:",
	set: "Ayarla"
});
