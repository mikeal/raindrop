run("i18n!dijit/_editor/nls/pl/LinkDialog",
{
	createLinkTitle: "Właściwości odsyłacza",
	insertImageTitle: "Właściwości obrazu",
	url: "Adres URL:",
	text: "Opis:",
	set: "Ustaw"
});
