run("i18n!dijit/_editor/nls/nb/LinkDialog",
{
	createLinkTitle: "Koblingsegenskaper",
	insertImageTitle: "Bildeegenskaper",
	url: "URL:",
	text: "Beskrivelse:",
	set: "Definer"
});
