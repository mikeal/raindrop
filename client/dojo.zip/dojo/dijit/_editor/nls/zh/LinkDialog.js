run.def("i18n!dijit/_editor/nls/zh/LinkDialog",
{
	createLinkTitle: "链接属性",
	insertImageTitle: "图像属性",
	url: "URL：",
	text: "说明：",
	set: "设置"
});
