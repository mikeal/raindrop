window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.zh.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.zh.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "zh", {"set":"集合","text":"描述：","insertImageTitle":"图像属性","url":"URL：","createLinkTitle":"链接属性"});
}};});