run("i18n!dijit/_editor/nls/ar/LinkDialog",
{
	createLinkTitle: "خصائص الوصلة",
	insertImageTitle: "خصائص الصورة",
	url: "عنوان URL:",
	text: "الوصف:",
	set: "تحديد"
});
