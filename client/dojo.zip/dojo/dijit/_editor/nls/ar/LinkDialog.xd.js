window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.ar.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.ar.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "ar", {"set":"تحديد","text":"الوصف: ","insertImageTitle":"خصائص الصورة ","url":"عنوان URL:","createLinkTitle":"خصائص الوصلة "});
}};});