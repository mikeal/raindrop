window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.zh-tw.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.zh-tw.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "zh-tw", {"set":"設定","text":"說明：","insertImageTitle":"影像檔內容","url":"URL：","createLinkTitle":"鏈結內容"});
}};});