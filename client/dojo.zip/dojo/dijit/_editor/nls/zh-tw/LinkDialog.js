run.def("i18n!dijit/_editor/nls/zh-tw/LinkDialog",
{
	createLinkTitle: "鏈結內容",
	insertImageTitle: "影像檔內容",
	url: "URL：",
	text: "說明：",
	set: "設定"
});
