run.def("i18n!dijit/_editor/nls/ru/LinkDialog",
{
	createLinkTitle: "Свойства ссылки",
	insertImageTitle: "Свойства изображения",
	url: "URL:",
	text: "Описание:",
	set: "Задать"
});
