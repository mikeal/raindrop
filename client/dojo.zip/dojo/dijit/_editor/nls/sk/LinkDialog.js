run.def("i18n!dijit/_editor/nls/sk/LinkDialog",
{
	createLinkTitle: "Vlastnosti odkazu",
	insertImageTitle: "Vlastnosti obrázku",
	url: "URL:",
	text: "Popis:",
	set: "Nastaviť"
});
