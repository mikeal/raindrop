run("i18n!dijit/_editor/nls/ja/LinkDialog",
{
	createLinkTitle: "リンク・プロパティー",
	insertImageTitle: "イメージ・プロパティー",
	url: "URL:",
	text: "説明:",
	set: "設定"
});
