run.def("i18n!dijit/_editor/nls/sl/FontChoice",
{
	fontSize: "Velikost",
	fontName: "Pisava",
	formatBlock: "Oblika",

	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",

	p: "Odstavek",
	h1: "Naslov",
	h2: "Podnaslov",
	h3: "Pod podnaslov",
	pre: "Vnaprej oblikovano",

	1: "xx-majhno",
	2: "x-majhno",
	3: "majhno",
	4: "srednje",
	5: "veliko",
	6: "x-veliko",
	7: "xx-veliko"
});
