window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.sl.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.sl.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "sl", {"set":"Nastavi","text":"Opis:","insertImageTitle":"Lastnosti slike","url":"URL:","createLinkTitle":"Lastnosti povezave"});
}};});