run("i18n!dijit/_editor/nls/sl/LinkDialog",
{
	createLinkTitle: "Lastnosti povezave",
	insertImageTitle: "Lastnosti slike",
	url: "URL:",
	text: "Opis:",
	set: "Nastavi"
});
