window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit._editor.nls.el.LinkDialog"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit._editor.nls.el.LinkDialog");dojo._xdLoadFlattenedBundle("dijit._editor", "LinkDialog", "el", {"set":"Ορισμός","text":"Περιγραφή:","insertImageTitle":"Ιδιότητες εικόνας","url":"Διεύθυνση URL:","createLinkTitle":"Ιδιότητες διασύνδεσης"});
}};});