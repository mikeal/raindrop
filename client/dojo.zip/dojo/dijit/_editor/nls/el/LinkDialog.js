run.def("i18n!dijit/_editor/nls/el/LinkDialog",
{
	createLinkTitle: "Ιδιότητες διασύνδεσης",
	insertImageTitle: "Ιδιότητες εικόνας",
	url: "Διεύθυνση URL:",
	text: "Περιγραφή:",
	set: "Ορισμός"
});
