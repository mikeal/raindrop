/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dijit._editor.plugins.ToggleDir"]){dojo._hasResource["dijit._editor.plugins.ToggleDir"]=true;dojo.provide("dijit._editor.plugins.ToggleDir");dojo.experimental("dijit._editor.plugins.ToggleDir");dojo.require("dijit._editor._Plugin");dojo.require("dijit.form.ToggleButton");dojo.declare("dijit._editor.plugins.ToggleDir",dijit._editor._Plugin,{useDefaultCommand:false,command:"toggleDir",buttonClass:dijit.form.ToggleButton,_initButton:function(){this.inherited(arguments);this.connect(this.button,"onChange","_toggleDir");var _1=this.editor.editorObject.contentWindow.document.documentElement;var _2=dojo.getComputedStyle(_1).direction=="ltr";this.button.attr("checked",!_2);},updateState:function(){},_toggleDir:function(){var _3=this.editor.editorObject.contentWindow.document.documentElement;var _4=dojo.getComputedStyle(_3).direction=="ltr";_3.dir=_4?"rtl":"ltr";}});dojo.subscribe(dijit._scopeName+".Editor.getPlugin",null,function(o){if(o.plugin){return;}switch(o.args.name){case "toggleDir":o.plugin=new dijit._editor.plugins.ToggleDir({command:o.args.name});}});}