run("dijit/_base", ["run", "dojo", "dijit", "dojox", "dijit/_base/focus", "dijit/_base/manager", "dijit/_base/place", "dijit/_base/popup", "dijit/_base/scroll", "dijit/_base/sniff", "dijit/_base/typematic", "dijit/_base/wai", "dijit/_base/window"], function(run, dojo, dijit, dojox, _R0, _R1, _R2, _R3, _R4, _R5, _R6, _R7, _R8) {
dojo.provide("dijit._base");

;
;
;
;
;
;
;
;
;

return dijit._base; });
