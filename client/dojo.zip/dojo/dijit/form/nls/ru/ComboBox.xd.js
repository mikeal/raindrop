window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ru.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ru.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "ru", {"previousMessage":"Предыдущие варианты","nextMessage":"Следующие варианты"});
}};});