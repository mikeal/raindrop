run("i18n!dijit/form/nls/el/ComboBox",
{
		previousMessage: "Προηγούμενες επιλογές",
		nextMessage: "Περισσότερες επιλογές"
});
