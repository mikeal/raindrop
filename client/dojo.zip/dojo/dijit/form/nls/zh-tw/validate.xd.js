window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.zh-tw.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.zh-tw.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "zh-tw", {"rangeMessage":"此值超出範圍。","invalidMessage":"輸入的值無效。","missingMessage":"必須提供此值。"});
}};});