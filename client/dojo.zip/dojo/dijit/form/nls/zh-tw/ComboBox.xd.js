window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.zh-tw.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.zh-tw.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "zh-tw", {"previousMessage":"前一個選擇項","nextMessage":"其他選擇項"});
}};});