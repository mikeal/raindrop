window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.pl.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.pl.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "pl", {"previousMessage":"Poprzednie wybory","nextMessage":"Więcej wyborów"});
}};});