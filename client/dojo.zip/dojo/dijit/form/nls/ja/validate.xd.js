window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ja.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ja.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "ja", {"rangeMessage":"この値は範囲外です。","invalidMessage":"入力した値は無効です。","missingMessage":"この値は必須です。"});
}};});