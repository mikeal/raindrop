window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ja.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ja.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "ja", {"previousMessage":"以前の選択項目","nextMessage":"追加の選択項目"});
}};});