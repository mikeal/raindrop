run("i18n!dijit/form/nls/pt-pt/ComboBox",
{
		previousMessage: "Opções anteriores",
		nextMessage: "Mais opções"
});
