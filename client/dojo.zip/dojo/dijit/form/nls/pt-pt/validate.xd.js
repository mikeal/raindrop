window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.pt-pt.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.pt-pt.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "pt-pt", {"rangeMessage":"Este valor encontra-se fora do intervalo.","invalidMessage":"O valor introduzido não é válido.","missingMessage":"O valor é requerido."});
}};});