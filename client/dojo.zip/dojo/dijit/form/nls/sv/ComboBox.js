run("i18n!dijit/form/nls/sv/ComboBox",
{
		previousMessage: "Föregående alternativ",
		nextMessage: "Fler alternativ"
});
