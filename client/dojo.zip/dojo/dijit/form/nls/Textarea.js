run("i18n!dijit/form/nls/Textarea",
{ "root": /* used by both the editor and textarea widgets to provide information to screen reader users */
{
	iframeEditTitle: 'edit area',  // primary title for editable IFRAME, for screen readers when focus is in the editing area
	iframeFocusTitle: 'edit area frame'  // secondary title for editable IFRAME when focus is on outer container
									 //  to let user know that focus has moved out of editing area and to the
									 //  parent element of the editing area
},
"ar": "i18n!dijit/form/nls/ar/Textarea",
"ca": "i18n!dijit/form/nls/ca/Textarea",
"cs": "i18n!dijit/form/nls/cs/Textarea",
"da": "i18n!dijit/form/nls/da/Textarea",
"de": "i18n!dijit/form/nls/de/Textarea",
"el": "i18n!dijit/form/nls/el/Textarea",
"es": "i18n!dijit/form/nls/es/Textarea",
"fi": "i18n!dijit/form/nls/fi/Textarea",
"fr": "i18n!dijit/form/nls/fr/Textarea",
"he": "i18n!dijit/form/nls/he/Textarea",
"hu": "i18n!dijit/form/nls/hu/Textarea",
"it": "i18n!dijit/form/nls/it/Textarea",
"ja": "i18n!dijit/form/nls/ja/Textarea",
"ko": "i18n!dijit/form/nls/ko/Textarea",
"nb": "i18n!dijit/form/nls/nb/Textarea",
"nl": "i18n!dijit/form/nls/nl/Textarea",
"pl": "i18n!dijit/form/nls/pl/Textarea",
"pt": "i18n!dijit/form/nls/pt/Textarea",
"pt-pt": "i18n!dijit/form/nls/pt-pt/Textarea",
"ru": "i18n!dijit/form/nls/ru/Textarea",
"sk": "i18n!dijit/form/nls/sk/Textarea",
"sl": "i18n!dijit/form/nls/sl/Textarea",
"sv": "i18n!dijit/form/nls/sv/Textarea"
});
