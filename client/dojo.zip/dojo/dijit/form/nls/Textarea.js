run.def("i18n!dijit/form/nls/Textarea",
{ "root": /* used by both the editor and textarea widgets to provide information to screen reader users */
{
	iframeEditTitle: 'edit area',  // primary title for editable IFRAME, for screen readers when focus is in the editing area
	iframeFocusTitle: 'edit area frame'  // secondary title for editable IFRAME when focus is on outer container
									 //  to let user know that focus has moved out of editing area and to the
									 //  parent element of the editing area
},
"ar": true,
"ca": true,
"cs": true,
"da": true,
"de": true,
"el": true,
"es": true,
"fi": true,
"fr": true,
"he": true,
"hu": true,
"it": true,
"ja": true,
"ko": true,
"nb": true,
"nl": true,
"pl": true,
"pt": true,
"pt-pt": true,
"ru": true,
"sk": true,
"sl": true,
"sv": true
});
