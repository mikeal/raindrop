run.def("i18n!dijit/form/nls/tr/ComboBox",
{
		previousMessage: "Önceki seçenekler",
		nextMessage: "Diğer seçenekler"
});
