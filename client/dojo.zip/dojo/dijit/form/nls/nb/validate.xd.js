window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.nb.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.nb.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "nb", {"rangeMessage":"Denne verdien er utenfor gyldig område.","invalidMessage":"Den angitte verdien er ikke gyldig.","missingMessage":"Denne verdien er obligatorisk."});
}};});