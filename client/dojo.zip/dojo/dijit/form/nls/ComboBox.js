run("i18n!dijit/form/nls/ComboBox",
{ "root": {
		previousMessage: "Previous choices",
		nextMessage: "More choices"
},
"ar": "i18n!dijit/form/nls/ar/ComboBox",
"ca": "i18n!dijit/form/nls/ca/ComboBox"
});
