run("i18n!dijit/form/nls/de/ComboBox",
{
		previousMessage: "Vorherige Auswahl",
		nextMessage: "Weitere Auswahlmöglichkeiten"
});
