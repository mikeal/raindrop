window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.de.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.de.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "de", {"rangeMessage":"Dieser Wert liegt außerhalb des gültigen Bereichs. ","invalidMessage":"Der eingegebene Wert ist ungültig. ","missingMessage":"Dieser Wert ist erforderlich."});
}};});