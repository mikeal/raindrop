window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.it.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.it.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "it", {"rangeMessage":"Questo valore non è compreso nell'intervallo.","invalidMessage":"Il valore immesso non è valido.","missingMessage":"Questo valore è obbligatorio."});
}};});