run.def("i18n!dijit/form/nls/he/ComboBox",
{
		previousMessage: "האפשרויות הקודמות",
		nextMessage: "אפשרויות נוספות"
});
