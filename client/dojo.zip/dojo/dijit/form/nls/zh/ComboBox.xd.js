window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.zh.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.zh.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "zh", {"previousMessage":"先前选项","nextMessage":"更多选项"});
}};});