window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.cs.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.cs.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "cs", {"rangeMessage":"Tato hodnota je mimo rozsah.","invalidMessage":"Zadaná hodnota není platná.","missingMessage":"Tato hodnota je vyžadována."});
}};});