run("i18n!dijit/form/nls/sl/ComboBox",
{
		previousMessage: "Prejšnje možnosti",
		nextMessage: "Dodatne možnosti"
});
