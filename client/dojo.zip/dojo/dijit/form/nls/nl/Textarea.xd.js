window[(typeof(djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.nl.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.nl.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "nl", {"iframeEditTitle":"veld bewerken","iframeFocusTitle":"veldkader bewerken"});
}};});