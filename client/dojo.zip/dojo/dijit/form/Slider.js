run("dijit/form/Slider", ["run", "dojo", "dijit", "dojox", "dijit/form/HorizontalSlider", "dijit/form/VerticalSlider", "dijit/form/HorizontalRule", "dijit/form/VerticalRule", "dijit/form/HorizontalRuleLabels", "dijit/form/VerticalRuleLabels"], function(run, dojo, dijit, dojox, _R0, _R1, _R2, _R3, _R4, _R5) {
dojo.provide("dijit.form.Slider");

dojo.deprecated("Call require() for HorizontalSlider / VerticalRule, explicitly rather than 'dijit.form.Slider' itself", "", "2.0");

// For back-compat, remove for 2.0
;
;
;
;
;
;


return dijit.form.Slider; });
