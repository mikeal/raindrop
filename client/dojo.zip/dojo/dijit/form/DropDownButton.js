run("dijit/form/DropDownButton", ["run", "dojo", "dijit", "dojox", "dijit/form/Button"], function(run, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.DropDownButton");
;


return dijit.form.DropDownButton; });
