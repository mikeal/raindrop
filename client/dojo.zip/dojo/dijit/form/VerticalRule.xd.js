/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


window[(typeof (djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(_1,_2,_3){return {depends:[["provide","dijit.form.VerticalRule"],["require","dijit.form.HorizontalRule"]],defineResource:function(_4,_5,_6){if(!_4._hasResource["dijit.form.VerticalRule"]){_4._hasResource["dijit.form.VerticalRule"]=true;_4.provide("dijit.form.VerticalRule");_4.require("dijit.form.HorizontalRule");_4.declare("dijit.form.VerticalRule",_5.form.HorizontalRule,{templateString:"<div class=\"dijitRuleContainer dijitRuleContainerV\"></div>",_positionPrefix:"<div class=\"dijitRuleMark dijitRuleMarkV\" style=\"top:",_isHorizontal:false});}}};});