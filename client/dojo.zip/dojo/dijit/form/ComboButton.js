run.def("dijit/form/ComboButton", ["run", "dojo", "dijit", "dojox", "dijit/form/Button"], function(run, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.ComboButton");
;

return dijit.form.ComboButton; });
