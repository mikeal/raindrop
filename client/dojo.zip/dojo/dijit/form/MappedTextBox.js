run.def("dijit/form/MappedTextBox", ["run", "dojo", "dijit", "dojox", "dijit/form/ValidationTextBox"], function(run, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.MappedTextBox");
;

return dijit.form.MappedTextBox; });
