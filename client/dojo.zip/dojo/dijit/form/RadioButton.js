run("dijit/form/RadioButton", ["run", "dojo", "dijit", "dojox", "dijit/form/CheckBox"], function(run, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.RadioButton");
;

// TODO: for 2.0, move the RadioButton code into this file

return dijit.form.RadioButton; });
