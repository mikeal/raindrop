run("dijit/form/RangeBoundTextBox", ["run", "dojo", "dijit", "dojox", "dijit/form/ValidationTextBox"], function(run, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.RangeBoundTextBox");
;

return dijit.form.RangeBoundTextBox; });
