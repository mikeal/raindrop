run.def("dijit/tests/i18n/module", ["run", "dojo", "dijit", "dojox"], function(run, dojo, dijit, dojox) {
dojo.provide("dijit.tests.i18n.module");

try{
	if(dojo.isBrowser){
		doh.registerUrl("dijit.tests.i18n.currency", dojo.moduleUrl("dijit", "tests/i18n/currency.html"));
		doh.registerUrl("dijit.tests.i18n.date", dojo.moduleUrl("dijit", "tests/i18n/date.html"));
		doh.registerUrl("dijit.tests.i18n.number", dojo.moduleUrl("dijit", "tests/i18n/number.html"));
		doh.registerUrl("dijit.tests.i18n.textbox", dojo.moduleUrl("dijit", "tests/i18n/textbox.html"));
		doh.registerUrl("dijit.tests.i18n.time", dojo.moduleUrl("dijit", "tests/i18n/time.html"));
		doh.registerUrl("dijit.tests.i18n.digit", dojo.moduleUrl("dijit", "tests/i18n/digit.html"));
	}
}catch(e){
	doh.debug(e);
}

return dijit.tests.i18n.module; });
