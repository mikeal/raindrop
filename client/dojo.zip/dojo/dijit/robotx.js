run("dijit/robotx", ["run", "dojo", "dijit", "dojox", "dijit/robot", "dojo/robotx"], function(run, dojo, dijit, dojox, _R0, _R1) {
dojo.provide("dijit.robotx");
;
;
dojo.experimental("dijit.robotx");
(function(){
var __updateDocument = doh.robot._updateDocument;

dojo.mixin(doh.robot,{
	_updateDocument: function(){
		__updateDocument();
		var win = dojo.global;
		if(win["dijit"]){
			dijit.registry = win.dijit.registry;
		}
	}
});

})();

return dijit.robotx; });
