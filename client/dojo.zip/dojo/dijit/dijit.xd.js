/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


window[(typeof (djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(_1,_2,_3){return {depends:[["provide","dijit.dijit"],["require","dijit._base"],["require","dojo.parser"],["require","dijit._Widget"],["require","dijit._Templated"],["require","dijit._Container"],["require","dijit.layout._LayoutWidget"],["require","dijit.form._FormWidget"]],defineResource:function(_4,_5,_6){if(!_4._hasResource["dijit.dijit"]){_4._hasResource["dijit.dijit"]=true;_4.provide("dijit.dijit");_4.require("dijit._base");_4.require("dojo.parser");_4.require("dijit._Widget");_4.require("dijit._Templated");_4.require("dijit._Container");_4.require("dijit.layout._LayoutWidget");_4.require("dijit.form._FormWidget");}}};});