/*
	Copyright (c) 2004-2009, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


window[(typeof (djConfig)!="undefined"&&djConfig.scopeMap&&djConfig.scopeMap[0][1])||"dojo"]._xdResourceLoaded(function(_1,_2,_3){return {depends:[["provide","dijit._Calendar"],["require","dijit.Calendar"]],defineResource:function(_4,_5,_6){if(!_4._hasResource["dijit._Calendar"]){_4._hasResource["dijit._Calendar"]=true;_4.provide("dijit._Calendar");_4.require("dijit.Calendar");_4.deprecated("dijit._Calendar is deprecated","dijit._Calendar moved to dijit.Calendar",1.5);_5._Calendar=_5.Calendar;}}};});